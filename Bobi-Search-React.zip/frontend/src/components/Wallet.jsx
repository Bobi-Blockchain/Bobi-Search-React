export default function Wallet() {
  return (
    <button className="connect-wallet-btn connect-wallet-state-btn">
      Connect
    </button>
  );
}
